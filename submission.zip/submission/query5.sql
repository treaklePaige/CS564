SELECT COUNT(SellerID)
FROM Sellers
WHERE (SellerRating > 1000);